/* ============================================================================

   Copyright (C) 2003, 2004, 2010, 2020  Konrad Bernloehr

   This file is part of the IACT/atmo package for CORSIKA.

   The IACT/atmo package is free software; you can redistribute it 
   and/or modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This package is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this package. If not, see <http://www.gnu.org/licenses/>.

============================================================================ */

/* ================================================================ */
/** @file sampling.c
 *  @short Interface for importance sampled core offset distributions.
 *
 *  Not used by default. The default distribution (per unit area) is flat.
 *
 *  @author  Konrad Bernloehr 
 *  @date    @verbatim CVS $Date: 2020/11/24 10:23:17 $ @endverbatim
 *  @version @verbatim CVS $Revision: 1.9 $ @endverbatim
 */
/* ================================================================ */

#include "initial.h"      /* This file includes others as required. */
#ifndef NO_FILEOPEN
#include "fileopen.h"
#endif
#include "sampling.h"
#include "rpolator.h"
#ifdef SAMPLING_TEST
#include <gsl/gsl_rng.h>
#endif

#ifdef __cplusplus
/* You can compile this file with a C++ compiler instead of a C compiler, if you want */
extern "C" {
#endif

#ifdef SAMPLING_TEST
gsl_rng *rng;
#define rndm(i) gsl_rng_uniform(rng)
#else
double iact_rndm(int dummy);
#define rndm(i) iact_rndm(i)
#endif

/* As long as there is no (non-uniform) sampling implementation,
   there are lots of unused function parameters, which we can safely ignore. */

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/**
   The three-zone sampling scheme has a flat distribution in the
     inner zone: 0 <= r < r1,
   a power-law (usually falling, k<0.) distribution in the
     middle zone: r1 <= r < r2,
   and again a flat distribution in the
     outer zone: r2 <= r <= r3
   with r3 usually implied as 1.0 because the generated
   positions are afterwards scaled with the CSCAT radius.
   Continuity of the distribution at r1 and r2 is enforced.
*/

static int three_zone_sample (double k, double r1, double r2, 
   double *xu, double *yu, double *awu);

static int three_zone_sample (double k, double r1, double r2, 
   double *xu, double *yu, double *awu)
{
   double r3 = 1.0;
   double ri[3], p[3], rs;
   double d;

   if ( r1 <= 0. || r2 < r1 || r2 > r3 )
   {
      fprintf(stderr,"Radii invalid in three_zone_sampling().\n");
      *xu = *yu = *awu = 0.;
      return -1;
   }

   ri[0] = M_PI * (r1*r1);
   if ( k != -2. )
      ri[1] = fabs((2.*M_PI)/(k+2.) * (pow(r2/r1,k+2.)-1.)) * (r1*r1);
   else
      ri[1] = (2.*M_PI) * log(r2/r1) * (r1*r1);
   ri[2] = M_PI * pow(r2/r1,k) * (r3*r3 - r2*r2);
   
   rs = ri[0] + ri[1] + ri[2];
   p[0] = ri[0]/rs;
   p[1] = ri[1]/rs;
   p[2] = ri[2]/rs;
   // long ni[3] = { 0, 0, 0 }, n = 0;

   double aw1 = M_PI*(r1*r1) / p[0];

#ifdef SAMPLING_TEST2
   double aw3 = aw1 * pow(r1/r2,k);
   double area = M_PI*(r3*r3);

   fprintf(stderr,"# Area = %f, p0=%f, p1=%f, p2=%f, aw1 = %f, aw3 = %f\n",
      area, p[0], p[1], p[2], aw1, aw3);
#endif
   
   double aw = 0.;
   double rn = rndm(0);
   if ( rn < p[0] && p[0] > 0. )
   {
      d = r1*sqrt(rn/p[0]);
      aw = aw1;
      // ni[0]++;
   }
   else if ( rn < p[0]+p[1] && p[1] > 0. )
   {
      double rn2 = (rn - p[0])/p[1];
      if ( k == -2. )
         d = r1 * exp(rn2*log(r2/r1));
      else
         d = r1 * pow((1. + rn2*(pow(r2/r1,k+2.)-1.)),1./(k+2.));
      aw = aw1 * pow(r1/d,k);
      // ni[1]++;
   }
   else if ( p[2] > 0. )
   {
      double rn3 = (rn - p[0]-p[1])/p[2];
      d = sqrt(r2*r2 + rn3*(r3*r3-r2*r2));
      aw = aw1 * pow(r1/r2,k);
      // ni[2]++;
   }
   else
   {
      d = r3;
      aw = 0.;
   }

   double phi = (2.*M_PI)*rndm(1);
   double x = d*cos(phi);
   double y = d*sin(phi);

#ifdef SAMPLING_TEST2
   fprintf(stdout,"%f\t%f\t%f\t%f\t%f\n",x,y,d,phi,aw);
#endif

   *xu = x;
   *yu = y;
   *awu= aw;
   
   return 0;
}

static int three_zone_scheme = 0; ///< Default scheme is fixed parameters
static double three_zone_fixed_k  = 0.0; ///< Default distribution is flat
static double three_zone_fixed_r1 = 1.0; ///< Flat from center to edge of unit circle.
static double three_zone_fixed_r2 = 1.0; ///< Flat from center to edge of unit circle.

static RpolTable *rpt_k = NULL;
static RpolTable *rpt_r1 = NULL;
static RpolTable *rpt_r2 = NULL;

/** Initialize 3-zone sampling with fixed parameters, independent of energy and zenith angle. */

static int three_zone_init_fixed(const char *paramtext);

static int three_zone_init_fixed(const char *paramtext)
{
   double k=0., r1=1.0, r2=1.0;
   if ( sscanf(paramtext,"%lf,%lf,%lf",&k,&r1,&r2) != 3 )
   {
      fprintf(stderr,"Invalid 3-zone sampling parameters: %s\n",paramtext);
      return -1;
   }

   if ( r1 < 0. || r2 < r1 || r2 > 1.0 )
   {
      fprintf(stderr,"Invalid 3-zone sampling parameters: k=%f,r1=%f,r2=%f (r3=:1.0)\n",k,r1,r2);
      return -1;
   }

   three_zone_scheme = 1;
   three_zone_fixed_k = k;
   three_zone_fixed_r1 = r1;
   three_zone_fixed_r2 = r2;
   
   return 0;
}

/** Initialize 3-zone sampling with a table depending only on primary energy. */

static int three_zone_init_1d(const char *fname);

static int three_zone_init_1d(const char *fname)
{
   /* Format of lines in table is: 
          E[GeV] k r1 r2
      Always implied is r3=1.0 (all radii to be scaled with CSCAT radius)
      Although the table has the energy in linear units,
      interpolation will be in log(E).
   */
   /* We read the same file into three interpolation tables */
   rpt_k  = read_rpol_table(fname,1,NULL,"scheme=1,xlog,ycol=2");
   rpt_r1 = read_rpol_table(fname,1,NULL,"scheme=1,xlog,ycol=3");
   rpt_r2 = read_rpol_table(fname,1,NULL,"scheme=1,xlog,ycol=4");
   if ( rpt_k == NULL || rpt_r1 == NULL || rpt_r2 == NULL )
   {
      fprintf(stderr,"Table '%s' not suitable for 1-D interpolation of 3-zone sampling parameters.\n",fname);
      return -1;
   }
   three_zone_scheme = 2;

   return 0;
}

/** Initialize 3-zone sampling with a table depending on primary energy and zenith angle. */

static int three_zone_init_2d(const char *fname);

static int three_zone_init_2d(const char *fname)
{
   /* Format of lines in table is: 
          E[GeV] theta[deg] k r1 r2
      Always implied is r3=1.0 (all radii to be scaled with CSCAT radius)
      Although the table has the energy in linear units,
      interpolation will be in log(E).
   */
   /* We read the same file into three interpolation tables */
   rpt_k  = read_rpol_table(fname,1,NULL,"scheme=1,xlog,zcol=3");
   rpt_r1 = read_rpol_table(fname,1,NULL,"scheme=1,xlog,zcol=4");
   rpt_r2 = read_rpol_table(fname,1,NULL,"scheme=1,xlog,zcol=5");

   if ( rpt_k == NULL || rpt_r1 == NULL || rpt_r2 == NULL )
   {
      fprintf(stderr,"Table '%s' not suitable for 2-D interpolation of 3-zone sampling parameters.\n",fname);
      return -1;
   }
   three_zone_scheme = 3;

   return 0;
}

static int three_zone_init(const char *text1);

static int three_zone_init(const char *text1)
{
   if ( text1 == NULL || *text1 == '\0' )
      return -1;
   char *text = strdup(text1); /* Need a local copy to avoid conflict with const */
   if ( text == NULL )
      return -1;

   /* If we get a raw line, including newline character, cut that off. */
   char *nl = strchr(text,'\n');
   if ( nl != NULL )
      *nl = '\0';
   /* We would prefer if we get instructions on how to interpolate. */
   char *s = strchr(text,':');
   int rc = 0;
   if ( s != NULL )
   {
      *s = '\0';
      if ( strcmp(text,"fixed") == 0 )
         rc = three_zone_init_fixed(s+1);
      else if ( strcmp(text,"1d") || strcmp(text,"1D") )
         rc = three_zone_init_1d(s+1);
      else if ( strcmp(text,"2d") || strcmp(text,"2D") )
         rc = three_zone_init_2d(s+1);
      else
      {
         fprintf(stderr,"Invalid three-zone sampling initialization string: %s:%s\n", text,s+1);
         rc = -1; 
      }
   }
   else 
   {
      /* Guessing what was meant ... */
      double k=0.,r1=0.,r2=0.;
      if ( sscanf(text,"%lf,%lf,%lf",&k,&r1,&r2) == 3 )
      {
         fprintf(stderr,"Initialize three-zone sampling assuming 'fixed:%s'\n",text);
         rc = three_zone_init_fixed(text);
      }
      else
      {
         fprintf(stderr,"Initialize three-zone sampling assuming '1d:%s'\n",text);
         rc = three_zone_init_1d(text);
      }
   }

   free(text);
   return rc;
}

/* ------------------------- sample_offset ---------------------------- */
/**
 *  @short Get uniformly sampled or importance sampled offset of array
 *         with respect to core, in the plane perpendicular to the shower axis.
 *
 *  @param sampling_fname Name of file with parameters, to be read on first call.
 *  @param core_range     Maximum core distance as used in data format check [cm].
 *                        If not obeying this maximum distance, make sure to switch on
 *                        the long data format manually.
 *  @param theta          Zenith angle [radians]
 *  @param phi            Shower azimuth angle in CORSIKA angle convention [radians].
 *  @param thetaref       Reference zenith angle (e.g. of VIEWCONE centre) [radians].
 *  @param phiref         Reference azimuth angle (e.g. of VIEWCONE centre) [radians].
 *  @param offax          Angle between central direction (typically VIEWCONE centre)
 *                        and the direction of the current primary [radians].
 *  @param E              Energy of primary particle [GeV]
 *  @param primary        Primary particle ID.
 *  @param xoff           X offset [cm] to be generated.
 *  @param yoff           Y offset [cm] to be generated.
 *  @param sampling_area  Area weight of the generated sample 
 *                        (normalized to Pi*core_range^2) [cm^2].
 */

void sample_offset (const char *sampling_fname, double core_range, 
   double theta, double phi, 
   double thetaref, double phiref, double offax, 
   double E, int primary,
   double *xoff, double *yoff, double *sampling_area)
{
   static int init_done = 0;
   
   if ( !init_done )
   {
      if ( sampling_fname != NULL && *sampling_fname != '\0' )
      {
         if ( three_zone_init(sampling_fname) != 0 )
         {
            fprintf(stderr,"Initializing importance sampling for core positions failed.\n");
            exit(1);
         }
      }
      init_done = 1;
   }
   
   int rc = -3;
   if ( three_zone_scheme == 1 )
      rc = three_zone_sample(three_zone_fixed_k, three_zone_fixed_r1, three_zone_fixed_r2,
         xoff, yoff, sampling_area);
   else if ( three_zone_scheme == 2 || three_zone_scheme == 3 )
   {
      if ( three_zone_scheme == 2 )
         theta = 0.;
      /* 1d and 2d tables work the same way, just theta being ignored for 1d */
      double k  = rpolate(rpt_k,  E, theta, 1);
      double r1 = rpolate(rpt_r1, E, theta, 1);
      double r2 = rpolate(rpt_r2, E, theta, 1);
#ifdef SAMPLING_TEST
      printf("Interpolated: E=%g: k=%f, r1=%f, r2=%f\n",E,k,r1,r2);
#endif
      if ( r1 < 0. || r2 < r1 || r2 > 1.0 )
         rc = -2;
      else
         rc = three_zone_sample(k, r1, r2, xoff, yoff, sampling_area);
   }
   
   if ( rc != 0 )
   {
      if ( three_zone_scheme != 0 )
         fprintf(stderr,"Importance sampling fails. Revert to flat distribution.\n");
      double R, p;
   
      /* In the absence of a real implementation, use uniform distribution. */
      R = core_range*sqrt(rndm(0));
      p = (2.*M_PI) * rndm(1);
      *xoff = R * cos(p);
      *yoff = R * sin(p);
      *sampling_area = M_PI*(core_range*core_range);
   }
   else
   {
      /* Scale results from 3-zone scheme by CSCAT radius */
      *xoff *= core_range;
      *yoff *= core_range;
      *sampling_area *= core_range*core_range;
   }
}

#ifdef SAMPLING_TEST
int main (int argc, char **argv)
{
   rng = gsl_rng_alloc (gsl_rng_ranlux);
   gsl_rng_set(rng,1234567);
   int nev = 20;
   
   char *fname = "";
   if ( argc > 1 )
   {
      fname = argv[1];
   }
   if ( argc > 2 )
      nev = atoi(argv[2]);
   double core_range = 1000.e2;
   double theta = 30.;
   double phi = 185.;
   double theta_ref = 20.;
   double phi_ref = 180.;
   double offax = 0.;
   int primary = 1;
   for ( int i=0;i<nev; i++ )
   {
      double xoff=0., yoff=0., aw=0.;
      double E = pow(10.,-2.+5.*rndm(3)) * 1e3;
      sample_offset(fname,core_range,theta,phi,theta_ref,phi_ref,offax,E,primary,&xoff,&yoff,&aw);
      printf("E=%g GeV (%g TeV), x=%f cm, y=%f cm, w=%f cm^2\n", E, E*1e-3, xoff, yoff, aw);
      printf("@S %f\t%f\t%f\t%f\t%g\n", log10(E*1e-3), xoff*1e-2, yoff*1e-2, sqrt(xoff*xoff+yoff*yoff)*1e-2,aw*1e-4);
   }
}
#endif

#pragma GCC diagnostic pop

#ifdef __cplusplus
}
#endif
