/*
   Copyright (C) 2016, 2019, 2020  Konrad Bernloehr

   This file is part of the IACT/atmo package for CORSIKA.

   The IACT/atmo package is free software; you can redistribute it 
   and/or modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This package is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this package. If not, see <http://www.gnu.org/licenses/>.
 */

/* ================================================================== */
/**
 *  @file iact.h
 *  @short Function declarations for CORSIKA IACT interface.
 *
 *  Function declarations are only needed if linking a C or C++ program
 *  to the IACT interface. The CORSIKA Fortran code is not using it.
 *
 *  @author  Konrad Bernloehr 
 *  @date    @verbatim CVS $Date: 2020/11/24 10:23:17 $ @endverbatim
 *  @date    @verbatim CVS $Revision: 1.13 $ @endverbatim
 *  @copyright LGPL2.1+
 *
*/

/* ==================================================================== */

#ifndef IACT_HEADER
#define IACT_HEADER 1

/** @ingroup iact_atmo_interface The CORSIKA iact/atmo interface */
/** @{ */

/* Length of primary particle data structure since CORSIKA 6.4 */
# define PRMPAR_SIZE 17

#ifdef __cplusplus
extern "C" {
#endif

/** Type for CORSIKA floating point numbers remaining REAL*4 */
typedef float cors_real_t;
/** Type for CORSIKA numbers which are currently REAL*8 */
typedef double cors_dbl_t;

void get_iact_stats (long *sb, double *ab, double *ap);
double iact_rndm(int dummy);
void ioerrorcheck(void);
void telfil_(const char *name);
void telsmp_(const char *name);
void telshw_(void);
void telinf_(int *itel, double *x, double *y, double *z, double *r, int *exists);
void telrnh_(cors_real_t runh[273]);
void tellni_(const char *line, int *llength);
void telrne_(cors_real_t rune[273]);
void telasu_(int *n, cors_dbl_t *dx, cors_dbl_t *dy);
void telset_(cors_dbl_t *x, cors_dbl_t *y, cors_dbl_t *z, cors_dbl_t *r);
void get_impact_offset(cors_real_t evth[273], cors_dbl_t prmpar[17]);
void televt_(cors_real_t evth[273], cors_dbl_t prmpar[17]);
int telout_(cors_dbl_t *bsize, cors_dbl_t *wt, cors_dbl_t *px, cors_dbl_t *py, 
   cors_dbl_t *pu, cors_dbl_t *pv, cors_dbl_t *ctime, cors_dbl_t *zem, cors_dbl_t *lambda);
void tellng_(int *type, double *data, int *ndim, int *np, int *nthick, double *thickstep);
void telend_(cors_real_t evte[273]);
void extprim_setup(const char *text);
void extprm_(cors_dbl_t *type, cors_dbl_t *eprim, double *thetap, double *phip);
void extprm5_(cors_dbl_t *type, cors_dbl_t *eprim, double *thetap, double *phip, double *ar);
void set_system_displacement(double dx, double dy);

extern double refidx_ (double *height);
extern double rhof_ (double *height);

extern int iact_check_track_(double *x1, double *y1, double *z1, double *t1, double *e1, double *eta1,
      double *x2, double *y2, double *z2, double *t2, double *e2, double *eta2,
      double *amass, double *charge, double *wtthin);

#ifdef __cplusplus
}
#endif

#endif
